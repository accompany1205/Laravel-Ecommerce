<div class="top-cart home3-top-cart home3-bg bg-5" id="productCart">
    <product-header-cart></product-header-cart>
</div>
<?php /**PATH /home/hsblco55/oneclick.hsblco.com/resources/views/website/ecommerce/layouts/header_cart.blade.php ENDPATH**/ ?>