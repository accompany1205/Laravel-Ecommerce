<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
    <div class="col-sm-9">
        <h4 class="page-title"><?php echo e($title); ?></h4>
        
    </div>
</div>
<!-- End Breadcrumb-->
<?php /**PATH /home/hsblco55/oneclick.hsblco.com/resources/views/admin/includes/bread_cumb.blade.php ENDPATH**/ ?>