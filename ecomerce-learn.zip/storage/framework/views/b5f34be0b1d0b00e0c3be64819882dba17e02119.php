<?php $__env->startSection('content'); ?>

    <div class="cart-main-container shop-bg">
        <div class="cart-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="woocommerce-breadcrumb mtb-15">
                            <div class="menu">
                                <ul>
                                    <li><a href="/">Home</a></li>
                                    <li class="active">invoice</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card card-body printableArea">
                            <h3><b>INVOICE</b> <span class="pull-right">#1422</span></h3>
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="pull-left">
                                        <address>
                                            <h3> &nbsp;<b class="text-danger">KhushiBd</b></h3>
                                            <p class="text-muted m-l-5">
                                                <br> Dhanmondi,
                                                <br> Dhaka,
                                                <br> Bangladesh
                                                <br> 01620006811
                                                <br> 01620006812
                                            </p>
                                        </address>
                                    </div>
                                    <div class="pull-right text-right">
                                        <address>
                                            <h3>To,</h3>
                                            <h4 class="font-bold"><?php echo e(Auth::user()->name); ?></h4>
                                            <p class="text-muted m-l-30">
                                                asdfasdf
                                            </p>
                                            <p class="m-t-30">
                                                <b>Invoice Date : </b>
                                                <br>
                                                <i class="fa fa-calendar"></i>
                                                <?php echo e(Carbon\Carbon::now()->format('d-m-y')); ?>

                                            </p>
                                            
                                        </address>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="table-responsive m-t-40" style="clear: both;">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">#</th>
                                                    <th>Description</th>
                                                    <th class="text-right">Quantity</th>
                                                    <th class="text-right">Unit Cost</th>
                                                    <th class="text-right">Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center">1</td>
                                                    <td> asdfasd </td>
                                                    <td class="text-right"> 234 </td>
                                                    <td class="text-right"> TK. 5345345 </td>
                                                    <td class="text-right"> TK. 34534 </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="pull-right m-t-30 text-right">
                                        <p>Sub-Total amount: TK. 345345</p>
                                        
                                        <hr>
                                        <h3><b>Total :</b> TK. 345345</h3>
                                    </div>
                                    <div class="clearfix"></div>
                                    <hr>
                                    <div class="text-right">
                                        
                                        <button id="print" class="btn btn-default btn-outline" type="button">
                                            <span><i class="fa fa-print"></i> Print</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php $__env->startPush('custom_js'); ?>
        <script src="<?php echo e(asset('contents/website')); ?>/js/jquery.PrintArea.js" type="text/JavaScript"></script>
        <script>
            $(document).ready(function() {
                $("#print").click(function() {
                    var mode = 'iframe'; //popup
                    var close = mode == "popup";
                    var options = {
                        mode: mode,
                        popClose: close
                    };
                    $("div.printableArea").printArea(options);
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.ecommerce.layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/website/ecommerce/invoice.blade.php ENDPATH**/ ?>