<div class="blog-area box-shadow bg-fff">
    <div class="product-title home3-bg text-uppercase">
        <i class="fa fa-comments-o icon home3-bg2"></i>
        <h3>LATEST BLOG</h3>
    </div>
    <div class="feautred-active right home2 left-right-angle">
        <div class="blog-wrapper">
            <div class="blog-img mtb-30">
                <a href="#">
                    <img src="<?php echo e(asset('contents/website')); ?>/img/blog/1.jpg" alt="" />
                </a>
            </div>
            <div class="blog-content home3-hover">
                <h3><a href="#">hello world</a></h3>
                <div class="blog-meta">
                    <span>April 18, 2016</span>
                    <span>0 Comment(s)</span>
                </div>
                <p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!Aenean posuere libero eu augue condimentum rhoncus. Praesent …</p>
            </div>
        </div>
        <div class="blog-wrapper">
            <div class="blog-img mtb-30">
                <a href="#">
                    <img src="<?php echo e(asset('contents/website')); ?>/img/blog/2.jpg" alt="" />
                </a>
            </div>
            <div class="blog-content home3-hover">
                <h3><a href="#">hello world</a></h3>
                <div class="blog-meta">
                    <span>April 18, 2016</span>
                    <span>0 Comment(s)</span>
                </div>
                <p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!Aenean posuere libero eu augue condimentum rhoncus. Praesent …</p>
            </div>
        </div>
        <div class="blog-wrapper">
            <div class="blog-img mtb-30">
                <a href="#">
                    <img src="<?php echo e(asset('contents/website')); ?>/img/blog/3.jpg" alt="" />
                </a>
            </div>
            <div class="blog-content home3-hover">
                <h3><a href="#">hello world</a></h3>
                <div class="blog-meta">
                    <span>April 18, 2016</span>
                    <span>0 Comment(s)</span>
                </div>
                <p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!Aenean posuere libero eu augue condimentum rhoncus. Praesent …</p>
            </div>
        </div>
        <div class="blog-wrapper">
            <div class="blog-img mtb-30">
                <a href="#">
                    <img src="<?php echo e(asset('contents/website')); ?>/img/blog/4.jpg" alt="" />
                </a>
            </div>
            <div class="blog-content home3-hover">
                <h3><a href="#">hello world</a></h3>
                <div class="blog-meta">
                    <span>April 18, 2016</span>
                    <span>0 Comment(s)</span>
                </div>
                <p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!Aenean posuere libero eu augue condimentum rhoncus. Praesent …</p>
            </div>
        </div>
        <div class="blog-wrapper">
            <div class="blog-img mtb-30">
                <a href="#">
                    <img src="<?php echo e(asset('contents/website')); ?>/img/blog/5.jpg" alt="" />
                </a>
            </div>
            <div class="blog-content home3-hover">
                <h3><a href="#">hello world</a></h3>
                <div class="blog-meta">
                    <span>April 18, 2016</span>
                    <span>0 Comment(s)</span>
                </div>
                <p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!Aenean posuere libero eu augue condimentum rhoncus. Praesent …</p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/hsblco55/oneclick.hsblco.com/resources/views/website/ecommerce/home_include/blog.blade.php ENDPATH**/ ?>