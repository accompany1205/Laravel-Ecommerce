<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('admin.includes.bread_cumb',['title'=>'Product Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title">Add Product</div>
                            <hr />
                            <form class="insert_form row" method="POST" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="preloader"></div>
                                <div class="form-group col-md-6 col-xl-4">
                                    <label for="" class=" col-form-label">Name</label>
                                    <?php echo $__env->make('admin.product.components.input',[
                                        'name' => 'product_name',
                                        'type' => 'text'
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Brand</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'brand',
                                        'attributes' => '',
                                        'class' => 'multiple-select',
                                        'collection' => $brands,
                                        'action' => route('brand.store'),
                                        'fields' => [
                                            ['name' => 'name','type' => 'text'],
                                            ['name' => 'icon','type' => 'file'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Main Category</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'product_main_category_id',
                                        'attributes' => '',
                                        'class' => 'multiple-select',
                                        'collection' => $maincategories,
                                        'action' => route('main_category.store'),
                                        'fields' => [
                                            ['name' => 'name','type' => 'text'],
                                            ['name' => 'icon','type' => 'file'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Category</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'product_category_id',
                                        'attributes' => 'multiple',
                                        'class' => 'multiple-select',
                                        'collection' => $categories,
                                        'action' => route('category.store'),
                                        'fields' => [
                                            ['name' => 'main_category_id','type' => 'select','option_route'=>route('get_main_category_json')],
                                            ['name' => 'name','type' => 'text'],
                                            ['name' => 'icon','type' => 'file'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Sub Category</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'product_sub_category_id',
                                        'attributes' => 'multiple',
                                        'class' => 'multiple-select',
                                        'collection' => $sub_categories,
                                        'action' => route('sub_category.store'),
                                        'fields' => [
                                            [
                                                'name' => 'main_category_id',
                                                'type' => 'select',
                                                'option_route'=>route('get_main_category_json'),
                                                'class' => 'component_modal_main_category parent_select',
                                                'this_field_will_contorl' => 'component_modal_category',
                                                'this_field_control_route' => route('get_all_cateogory_selected_by_main_category',''),
                                                // 'this_field_control_route' => '',
                                            ],
                                            [
                                                'name' => 'category_id',
                                                'class' => 'component_modal_category',
                                                'type' => 'select',
                                                'option_route'=>''
                                            ],
                                            ['name' => 'name','type' => 'text'],
                                            ['name' => 'icon','type' => 'file'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Writer</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'writer_id',
                                        'attributes' => 'multiple',
                                        'class' => 'multiple-select',
                                        'collection' => $writers,
                                        'action' => route('writer.store'),
                                        'fields' => [
                                            ['name' => 'name','type' => 'text'],
                                            ['name' => 'description','type' => 'textarea'],
                                            ['name' => 'image','type' => 'file'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Publication</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'publication_id',
                                        'attributes' => 'multiple',
                                        'class' => 'multiple-select',
                                        'collection' => $publications,
                                        'action' => route('publication.store'),
                                        'fields' => [
                                            ['name' => 'name','type' => 'text'],
                                            ['name' => 'image','type' => 'file'],
                                            ['name' => 'description','type' => 'textarea'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Color</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'color_id',
                                        'attributes' => 'multiple',
                                        'class' => 'multiple-select',
                                        'collection' => $colors,
                                        'action' => route('color.store'),
                                        'fields' => [
                                            ['name' => 'name', 'type' => 'text'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Size</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'size_id',
                                        'attributes' => 'multiple',
                                        'class' => 'multiple-select',
                                        'collection' => $sizes,
                                        'action' => route('size.store'),
                                        'fields' => [
                                            ['name' => 'name', 'type' => 'text'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Unit</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'unit_id',
                                        'attributes' => 'multiple',
                                        'class' => 'multiple-select',
                                        'collection' => $units,
                                        'action' => route('unit.store'),
                                        'fields' => [
                                            ['name' => 'name', 'type' => 'text'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Vendor</label>
                                    <?php echo $__env->make('admin.product.components.select',[
                                        'name' => 'vendor_id',
                                        'attributes' => 'multiple',
                                        'class' => 'multiple-select',
                                        'collection' => $vendors,
                                        'action' => route('vendor.store'),
                                        'fields' => [
                                            ['name' => 'name', 'type' => 'text'],
                                            ['name' => 'email', 'type' => 'email'],
                                            ['name' => 'mobile_no', 'type' => 'text'],
                                            ['name' => 'image', 'type' => 'file'],
                                            ['name' => 'address', 'type' => 'textarea'],
                                            ['name' => 'description', 'type' => 'textarea'],
                                        ]
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6 col-xl-4">
                                    <label for="" class=" col-form-label">Price</label>
                                    <?php echo $__env->make('admin.product.components.input',[
                                        'name' => 'price',
                                        'type' => 'text'
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6 col-xl-4">
                                    <label for="" class=" col-form-label">Discount</label>
                                    <?php echo $__env->make('admin.product.components.input',[
                                        'name' => 'discount',
                                        'type' => 'text'
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6 col-xl-4">
                                    <label for="" class=" col-form-label">Expiration Date</label>
                                    <?php echo $__env->make('admin.product.components.input',[
                                        'name' => 'expiration_date',
                                        'type' => 'date'
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6 col-xl-4">
                                    <label for="" class=" col-form-label">Stock</label>
                                    <?php echo $__env->make('admin.product.components.input',[
                                        'name' => 'stock',
                                        'type' => 'number'
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6 col-xl-4">
                                    <label for="" class=" col-form-label">Alert Quantity</label>
                                    <?php echo $__env->make('admin.product.components.input',[
                                        'name' => 'alert_quantity',
                                        'type' => 'number'
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="col-12"></div>

                                <div class="form-group col-md-6 col-xl-6">
                                    <label for="" class=" col-form-label">Description</label>
                                    <div class="">
                                        
                                        <textarea name="description" class="form-control" id="mytextarea1" cols="30" rows="10"></textarea>
                                        <span class="text-danger description"></span>
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-xl-6">
                                    <label for="" class=" col-form-label">Features</label>
                                    <div class="">
                                        
                                        <textarea name="features" class="form-control" id="mytextarea2" cols="30" rows="10"></textarea>
                                        <span class="text-danger features"></span>
                                    </div>
                                </div>

                                <div class="form-group col-md-6 col-xl-6">
                                    <label for="" class=" col-form-label">Thumb Image</label>
                                    <?php echo $__env->make('admin.product.components.input',[
                                        'name' => 'thumb_image',
                                        'type' => 'file'
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class="form-group col-md-6 col-xl-6">
                                    <label for="" class=" col-form-label">Related Image</label>
                                    <div class="">
                                        <input type="file" multiple name="related_images[]" class="form-control"  placeholder="Alert" />
                                        <span class="text-danger related_images"></span>
                                    </div>
                                </div>

                                <div class="form-group col-md-6  col-xl-4">
                                    <label for="" class="col-form-label">Staus</label>
                                    <div class="">
                                        <select name="status"  class="form-control">
                                            <option value="draft">Draft</option>
                                            <option value="active">Active</option>
                                        </select>
                                        <span class="text-danger status"></span>
                                    </div>
                                </div>

                                <div class="form-group col-12">
                                    <label class="col-form-label"></label>
                                    <div class="">
                                        <button type="submit" class="btn btn-white px-5"><i class="icon-lock"></i> Upload</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

    <?php $__env->startPush('ccss'); ?>
        <link href="/contents/admin/plugins/select2/css/select2.min.css" rel="stylesheet" />
        <link href="/contents/admin/plugins/select2/css/select2-bootstrap4.css" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('contents/admin')); ?>/plugins/summernote/dist/summernote-bs4.css" />
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('cjs'); ?>
        <script src="/contents/admin/plugins/select2/js/select2.min.js"></script>
        <script src="<?php echo e(asset('contents/admin')); ?>/plugins/summernote/dist/summernote-bs4.min.js"></script>
        

        <script>
            $('.multiple-select').select2({
                // theme: 'bootstrap4',
                // width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
                placeholder: $(this).data('placeholder'),
                allowClear: Boolean($(this).data('allow-clear')),
            });
            // tinymce.init({
            //     selector: '#mytextarea1'
            // });
            // tinymce.init({
            //     selector: '#mytextarea2'
            // });
            $('#mytextarea1').summernote({
                height: 400,
                tabsize: 2
            });

            $('#mytextarea2').summernote({
                height: 400,
                tabsize: 2
            });

            $('#selectmain_category_id').on('change',function(){
                let value = $(this).val();
                $.get("/admin/product/get-all-cateogory-selected-by-main-category/"+value,(res)=>{
                    $('#selectcategory_id').html(res);
                })
            })
        </script>

        <script>

        </script>
    <?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/admin/product/create.blade.php ENDPATH**/ ?>