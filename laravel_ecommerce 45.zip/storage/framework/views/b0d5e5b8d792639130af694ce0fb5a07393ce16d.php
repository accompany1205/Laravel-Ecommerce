<div class="categories-menu text-uppercase home3-bg2 home3-categories-menu click" >
    <i class="fa fa-list-ul"></i>
    <span>All Categories</span>
</div>
<div class="menu-container home3-menu-container home3-hover toggole" style="<?php echo e(isset($_SERVER['PATH_INFO'])?'display: none':''); ?>">
    <ul>
        <li>
            <a href="#"><i class="fa fa-laptop"></i> Electronics <i class="fa fa-angle-right pull-right"></i></a>
            <ul class="megamenu-2 home3-megamenu-2 box-shadow">
                <li>
                    <a class="mega-title bb" href="shop-style-1.html">Men's</a>
                    <a href="shop-style-1.html">hats</a>
                    <a href="shop-style-1.html">music</a>
                    <a href="shop-style-1.html">singles</a>
                </li>
                <li>
                    <a class="mega-title bb" href="#">Sports & Outdoors</a>
                    <a href="shop-style-1.html">Smartphone</a>
                    <a href="shop-style-1.html">women's</a>
                    <a href="shop-style-1.html">Health & Beauty</a>
                </li>
                <li>
                    <a class="mega-title bb" href="#">Accessories</a>
                    <a href="#">Hobbies</a>
                    <a href="#">Networking</a>
                    <a href="#">Accessories</a>
                    <a href="#">Clothing</a>
                </li>
                <li>
                    <a class="mega-title bb" href="#">Laptops & Accessories</a>
                    <a href="#">Hobbies</a>
                    <a href="#">Clothing</a>
                    <a href="#">Flashlights</a>
                    <a href="shop-style-1.html">music</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#"><i class="fa fa-mobile"></i> Smartphone & Tablets </a>
        </li>
        <li>
            <a href="#"><i class="fa fa-medkit"></i> Health & Beauty</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-futbol-o"></i> Sports & Outdoors</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-compass"></i> Bags, Shoes & Accessories</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-shopping-bag"></i> Toys & Hobbies</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-desktop"></i> Computers & Networking</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-laptop"></i> Laptops & Accessories</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-clock-o"></i> Jewelry & Watches</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-chrome"></i> Flashlights & Lamps</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-star"></i> Headlight</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-plus-square-o"></i> More Categories</a>
        </li>
    </ul>
</div>
<?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/website/ecommerce/layouts/menu_sidebar.blade.php ENDPATH**/ ?>