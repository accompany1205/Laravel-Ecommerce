<div class="">
    <input type="text" name="<?php echo e($name); ?>" class="form-control"  placeholder="<?php echo e($name); ?>" />
    <span class="text-danger <?php echo e($name); ?>"></span>
    <style>
        .price{
            font-size: unset
        }
    </style>
</div>
<?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/admin/product/components/input.blade.php ENDPATH**/ ?>