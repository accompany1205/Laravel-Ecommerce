<div class="">
    <input type="text" name="{{ $name }}" class="form-control"  placeholder="{{ $name }}" />
    <span class="text-danger {{ $name }}"></span>
    <style>
        .price{
            font-size: unset
        }
    </style>
</div>
