<div class="logo hm3-logo">
    <a href="/">
        <img src="{{ asset('contents/website') }}/img/logo/1.png" alt="" />
    </a>
</div>
