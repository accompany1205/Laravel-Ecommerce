<div class="language-menu dropdown home3-hover">
    <ul>
        <li>
            <a href="#">eng <i class="fa fa-angle-down"></i></a>
            <ul>
                <li><a href="#">France</a></li>
                <li><a href="#">Germany</a></li>
                <li><a href="#">Japanese</a></li>
            </ul>
        </li>
        <li>
            <a href="#">usd <i class="fa fa-angle-down"></i></a>
            <ul>
                <li><a href="#">EUR - Euro</a></li>
                <li><a href="#">GBP - British Pound</a></li>
                <li><a href="#">INR - Indian Rupee</a></li>
            </ul>
        </li>
    </ul>
</div>
